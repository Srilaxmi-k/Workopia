package com.oiuj;

public class Ccc implements aaa{

	@Override
	public void display() {
		System.out.println("im in C");
		
	}

	@Override
	public void print() {
		System.out.println("im in C from print method");
	}

}
