package com.oiuj;

public class MainAaa {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
aaa ob1=new Bbb();
ob1.print();
ob1.display();
	}

}
