package com.infy.springIoc.Ioc;

public interface Sim {
public void calling();
public void browse();
}
