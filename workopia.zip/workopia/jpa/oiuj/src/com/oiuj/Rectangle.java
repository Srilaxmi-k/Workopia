package com.oiuj;

public class Rectangle {
int length;
int breadth;
public Rectangle(int length, int breadth) {
	super();
	this.length = length;
	this.breadth = breadth;
}
int area()
{
	return length*breadth;
}
}
