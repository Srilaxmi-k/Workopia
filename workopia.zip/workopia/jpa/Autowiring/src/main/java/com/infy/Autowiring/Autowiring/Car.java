package com.infy.Autowiring.Autowiring;

public class Car {

}
