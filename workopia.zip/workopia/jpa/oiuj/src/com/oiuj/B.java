package com.oiuj;

public class B extends A {
	public void prin()
	{
		System.out.println("im in b");
	}

}
