package com.oiuj;

public class A {
public void dis() {
	System.out.println("im in a");
}
}
