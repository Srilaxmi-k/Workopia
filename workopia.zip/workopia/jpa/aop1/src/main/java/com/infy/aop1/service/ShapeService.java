package com.infy.aop1.service;

import com.infy.aop1.model.Circle;
import com.infy.aop1.model.triangle;

public class ShapeService {
private Circle cir;
private triangle tri;
public Circle getCir() {
	return cir;
}
public void setCir(Circle cir) {
	this.cir = cir;
}
public triangle getTri() {
	return tri;
}
public void setTri(triangle tri) {
	this.tri = tri;
}



}
