package com.oiuj;

public class Rect {

	public static void main(String[] args) {
Rectangle ob1=new Rectangle(10,20);
Rectangle ob2=new Rectangle(20,20);
int a1=ob1.area();
int a2=ob2.area();
System.out.println("area of objects is "+a1+' ' +a2);
	}

}
