package com.oiuj;

public interface aaa {
	public void display();
	public void print();
}
