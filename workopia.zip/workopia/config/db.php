<?php

return[
    'host'=>'localhost',
    'port'=>3306,
    'dbname'=>'workopia',
    'username'=>'sample',
    'password'=>'Ranji!23'
];