package com.infy.temp2.Doa;

import infy.temp2.employee1;

public interface employee1Dao {
public int saveEmp(employee1 e);
public int updateEmp(employee1 e);
public int deleteEmp(employee1 e);
}
