package com.infy.Autowiring.Autowiring;

public class Address {

}
