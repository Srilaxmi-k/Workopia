package com.oiuj;

public class Bbb implements aaa{

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("im in display method");
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("im in print method");
	}

}
