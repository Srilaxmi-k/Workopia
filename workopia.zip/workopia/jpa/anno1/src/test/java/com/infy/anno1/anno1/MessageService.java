package com.infy.anno1.anno1;

public interface MessageService {
public void sendm(String msg);
}
