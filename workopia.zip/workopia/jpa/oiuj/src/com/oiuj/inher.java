package com.oiuj;

public class inher {

	public static void main(String[] args) {
B ob1=new B();
ob1.prin();
ob1.dis();	}

}
